# DisplayDriverTask API

The `DisplayDriverTask` class encompasses the thread necessary to concurrently interact with the Display hardware. It inherits from the `Task` class and uses the `DisplayDriver` class to communicate with the hardware. It provides data structures and high level methods to easily send data to the display.

```cpp
#include "DisplayDriverTask.h"

// instantiate the display task
DisplayDriverTask disp();

// try starting the thread
if (not disp.start())
{
    std::cerr << "Could not start DisplayDriverTask." << std::endl;
    exit(-1);
}

// use high-level API to print data
DisplayLines lines = { "Hello", "world!" };
disp.print(lines);

// or lazy dog style
disp.print({ "Hello", "world!" });

// use the task/event interface
Event e(disp::PRINT_EVENT, DisplayLines{ "Hello", "world!" });
disp.sendEventToTask(e);
```

